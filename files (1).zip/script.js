/* ===== LÓGICA (JavaScript) =====
   1) parse: lê os números digitados
   2) perc/moda: funções estatísticas auxiliares
   3) calcular: calcula tudo e escreve na tela
   4) boxplot: desenha o gráfico em SVG
   5) eventos: ligam os botões às funções */

// atalho para document.getElementById
const $ = id => document.getElementById(id);
const f = (x, d = 4) => Number.isFinite(x) ? x.toLocaleString("pt-BR", {maximumFractionDigits: d}) : "—";

// 1) Converte o texto digitado em lista de números
function parse(t) {
  const parts = t.replace(/[–—]/g, " ").split(/[\s;]+/).filter(Boolean);
  const out = [];
  for (const p of parts) {
    const n = Number(p.replace(",", "."));
    if (Number.isNaN(n)) return {erro: "Valor inválido: “" + p + "”"};
    out.push(n);
  }
  return {v: out};
}
// 2) Percentil por interpolação linear (mesmo método do Excel: INC)
function perc(s, p) {
  const h = (s.length - 1) * p / 100, lo = Math.floor(h), hi = Math.ceil(h);
  return s[lo] + (h - lo) * (s[hi] - s[lo]);
}
function moda(v) {
  const c = new Map();
  v.forEach(x => c.set(x, (c.get(x) || 0) + 1));
  const freq = [...c.values()], mx = Math.max(...freq);
  if (freq.every(q => q === freq[0])) return {m: [], tipo: "Amodal (não existe moda)"};
  const m = [...c].filter(([, q]) => q === mx).map(([x]) => x).sort((a, b) => a - b);
  return {m, tipo: m.length === 1 ? "Unimodal" : "Multimodal"};
}
const card = (l, v, extra = "") => `<div class="m"><small>${l}</small><b>${v}</b>${extra}</div>`;

// 3) Função principal: chamada ao clicar em Calcular
function calcular() {
  $("erro").textContent = "";
  const r = parse($("dados").value);
  if (r.erro) { $("erro").textContent = r.erro; $("res").hidden = true; return; }
  const v = r.v, n = v.length;
  if (n < 2) { $("erro").textContent = "Informe pelo menos 2 valores."; $("res").hidden = true; return; }
  const s = [...v].sort((a, b) => a - b), amostra = $("tipo").value === "1";
  const soma = v.reduce((a, b) => a + b, 0), media = soma / n;
  const md = perc(s, 50), q1 = perc(s, 25), q3 = perc(s, 75);
  const k = Math.min(100, Math.max(0, Number($("pk").value) || 0)), pk = perc(s, k);
  const mo = moda(v), min = s[0], max = s[n - 1];
  const sq = v.reduce((a, x) => a + (x - media) ** 2, 0);
  const den = amostra ? n - 1 : n, vari = sq / den, dp = Math.sqrt(vari);
  const cv = media !== 0 ? Math.abs(dp / media) * 100 : NaN;

  $("pos").innerHTML =
    card("n (observações)", n) + card("Soma", f(soma)) + card("Média", f(media)) +
    card("Mediana (Md)", f(md)) +
    card("Moda (Mo)", mo.m.length ? mo.m.map(x => f(x)).join(", ") : "—", `<br><span class="tag">${mo.tipo}</span>`) +
    card("Mínimo", f(min)) + card("Máximo", f(max)) +
    card("Q1 (25%)", f(q1)) + card("Q3 (75%)", f(q3)) +
    card("D" + (k / 10 % 1 === 0 ? k / 10 : "?") + " / P" + k, f(pk), `<small>${k}% dos valores ficam abaixo disso</small>`);

  $("disp").innerHTML =
    card("Amplitude (H)", f(max - min)) + card("Amplitude interquartil", f(q3 - q1)) +
    card("Variância (S²)", f(vari)) + card("Desvio padrão (S)", f(dp)) +
    card("Coef. de variação (CV)", f(cv, 2) + "%");
  $("cvtxt").innerHTML = Number.isFinite(cv)
    ? `CV ${cv <= 30 ? "≤" : ">"} 30%: <span class="tag">${cv <= 30 ? "Grupo homogêneo" : "Grupo heterogêneo"}</span>` : "CV indefinido (média igual a zero).";

  // Assimetria
  const as2 = dp > 0 ? 3 * (media - md) / dp : 0;
  const as1 = (dp > 0 && mo.m.length === 1) ? (media - mo.m[0]) / dp : NaN;
  const tol = 0.05;
  const forma = as2 > tol ? "Assimetria positiva (à direita)" : as2 < -tol ? "Assimetria negativa (à esquerda)" : "Simétrica (assimetria nula)";
  const expl = as2 > tol ? "Moda &lt; Mediana &lt; Média: maior concentração de valores baixos, cauda à direita."
    : as2 < -tol ? "Média &lt; Mediana &lt; Moda: maior concentração de valores altos, cauda à esquerda."
    : "Média, mediana e moda próximas: distribuição simétrica.";
  $("assi").innerHTML = card("1º coef. de Pearson", f(as1), "<small>(Média − Mo) / S</small>") +
    card("2º coef. de Pearson", f(as2), "<small>3·(Média − Md) / S</small>") +
    card("Classificação", `<span style="font-size:1rem">${forma}</span>`);
  $("assitxt").innerHTML = expl + (mo.m.length === 1 ? "" : " <span style='color:var(--mu)'>(O 1º coeficiente exige moda única.)</span>");

  boxplot(min, q1, md, q3, max, s);

  // passo a passo
  $("passo").textContent = `Média = ${f(media)} · Divisor = ${amostra ? "n − 1" : "n"} = ${den} · Soma dos quadrados = ${f(sq)} · S² = ${f(vari)} · S = ${f(dp)}`;
  $("tab").innerHTML = "<tr><th>xᵢ</th><th>xᵢ − média</th><th>(xᵢ − média)²</th></tr>" +
    v.map(x => `<tr><td>${f(x)}</td><td>${f(x - media)}</td><td>${f((x - media) ** 2)}</td></tr>`).join("") +
    `<tr><th>Σ</th><th>${f(v.reduce((a, x) => a + x - media, 0), 4)}</th><th>${f(sq)}</th></tr>`;
  $("ord").textContent = s.map(x => f(x)).join(" – ");
  $("res").hidden = false;
}

// 4) Desenha o box-plot em SVG com os 5 números
function boxplot(min, q1, md, q3, max, s) {
  const W = 640, L = 30, R = 610, y = 55, h = 36;
  const iqr = q3 - q1, lo = q1 - 1.5 * iqr, hi = q3 + 1.5 * iqr;
  const wmin = s.find(x => x >= lo), wmax = [...s].reverse().find(x => x <= hi);
  const out = s.filter(x => x < lo || x > hi);
  const a = min, b = max, span = (b - a) || 1;
  const X = x => L + (x - a) / span * (R - L);
  const st = 'stroke="currentColor" stroke-width="2"';
  let g = `<g style="color:var(--ac)">`;
  g += `<line x1="${X(wmin)}" x2="${X(q1)}" y1="${y}" y2="${y}" ${st}/><line x1="${X(q3)}" x2="${X(wmax)}" y1="${y}" y2="${y}" ${st}/>`;
  g += `<line x1="${X(wmin)}" x2="${X(wmin)}" y1="${y - 10}" y2="${y + 10}" ${st}/><line x1="${X(wmax)}" x2="${X(wmax)}" y1="${y - 10}" y2="${y + 10}" ${st}/>`;
  g += `<rect x="${X(q1)}" y="${y - h / 2}" width="${Math.max(2, X(q3) - X(q1))}" height="${h}" fill="var(--ac2)" ${st}/>`;
  g += `<line x1="${X(md)}" x2="${X(md)}" y1="${y - h / 2}" y2="${y + h / 2}" stroke="var(--wa)" stroke-width="3"/>`;
  out.forEach(x => g += `<circle cx="${X(x)}" cy="${y}" r="4" fill="none" ${st}/>`);
  g += `</g>`;
  const lab = [[min, "Mín"], [q1, "Q1"], [md, "Md"], [q3, "Q3"], [max, "Máx"]];
  lab.forEach(([x, t], i) => {
    const up = i % 2 === 0;
    g += `<text x="${X(x)}" y="${up ? 22 : 108}" text-anchor="middle">${t}: ${f(x, 2)}</text>`;
  });
  $("box").innerHTML = g;
}

// 5) Eventos
$("calc").onclick = calcular;
$("dados").addEventListener("keydown", e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) calcular(); });
$("tipo").onchange = $("pk").onchange = () => { if (!$("res").hidden) calcular(); };
$("limpar").onclick = () => { $("dados").value = ""; $("res").hidden = true; $("erro").textContent = ""; };
document.querySelectorAll("[data-ex]").forEach(b => b.onclick = () => { $("dados").value = b.dataset.ex; calcular(); });
